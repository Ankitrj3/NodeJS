const Book = require("../models/Book");

const getAllBooks = async (req, res)=>{

}
const getBookById = async (req, res)=>{
    
}
const createBook = async (req, res) => {
    try {
      const newBookFormData = req.body;
      const newBook = await Book.create(newBookFormData);
      
      if (newBook) {
        res.status(201).json({
          message: "New book created successfully",
          data: newBook
        });
      }
  
    } catch (err) {
      console.log("Error in creating book", err);
      res.status(500).json({ message: "Error creating book", error: err.message });
    }
  };
  
const updateBook = async (req, res)=>{
    
}
const deleteBook = async (req, res)=>{

}
module.exports = {getAllBooks, getBookById, createBook, updateBook, deleteBook};